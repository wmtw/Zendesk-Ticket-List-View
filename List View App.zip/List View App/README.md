# List View Application

This application groups Views leveraging the same grouping method as Dropdowns. Seperate groups by '::' to create folders.

### The following information is displayed:

Please submit bug reports to 

### Screenshot(s):
N/A
